﻿namespace UnityTwine
{
	public enum TwineStoryState
	{
		Idle = 0,
		Playing = 1,
		Paused = 2,
		Exiting = 3,
		Complete = 10
	}
}